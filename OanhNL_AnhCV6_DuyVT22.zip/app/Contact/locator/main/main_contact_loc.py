contact_app_package = "com.samsung.android.contacts"
contact_app_activity = ".contactslist.PeopleActivity"

add_contact_button = "//*[@content-desc='Create contact']"
save_to_phone = "//*[@resource-id='android:id/text1' and @text='Phone']"
set_save_button = "//*[contains(@resource-id,'button1')]"