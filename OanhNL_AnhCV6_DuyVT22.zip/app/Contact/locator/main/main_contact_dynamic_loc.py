def get_created_contact(ct_name):
    return f"//*[@content-desc='{ct_name}']"