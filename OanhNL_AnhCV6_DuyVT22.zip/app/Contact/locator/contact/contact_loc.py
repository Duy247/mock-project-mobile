more_option = "//*[@content-desc='More options']"
delete_contact_option = "//*[@text='Delete']"
confirm_contact_delete_button = "//*[contains(@resource-id,'button1')]"