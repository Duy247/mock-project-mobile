name_input = "//*[contains(@resource-id,'nameEdit')]"
phone_holder = "//android.widget.TextView[@text='Phone']"
phone_input = "//android.widget.EditText[@text='Phone']"
save_button = "//*[@content-desc='Save']"

