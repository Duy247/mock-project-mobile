message_app_package = "com.samsung.android.messaging"
message_app_activity = "com.android.mms.ui.ConversationComposer"

create_new_message = "//*[@content-desc='Compose new message']"


