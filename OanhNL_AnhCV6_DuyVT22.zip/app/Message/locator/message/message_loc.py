recipient_field= "//*[contains(@resource-id,'recipients_editor_to')]"
contact_search_result = "//*[contains(@resource-id,'bubble_list_view')]/android.widget.LinearLayout"
message_field= "//*[@resource-id='com.samsung.android.messaging:id/message_edit_text']"
send_button = "//*[@content-desc='Send']"
conversation_setting = "//*[@content-desc='Conversation settings']"
delete_message = "//*[@text='Delete message']"
delete_button = "//*[@content-desc='Delete, Button']"
confirm_message_delete_button = "//*[@resource-id='android:id/button1']"

