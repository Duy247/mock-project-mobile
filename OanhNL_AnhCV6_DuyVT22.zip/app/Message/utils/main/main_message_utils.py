def format_number(ct_number):
    ct_number = str(ct_number)
    formatted_number = ' '.join(ct_number) + ' '
    return formatted_number
