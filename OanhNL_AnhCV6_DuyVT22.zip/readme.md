3 test case assignments

Written with POM design

Parameters:

```robot
${APPIUM_URL}    http://127.0.0.1:4723
${PLATFORM_NAME}    Android
${PLATFORM_VERSION}    9
${DEVICE_NAME}    32006e3ac01f9573
${ANDROID_AUTOMATION_NAME}    UiAutomator2
```

Update 1: Write test case 3 for Samsung A7 2018 Android 9

Update 2: Merge in test case 1 and test case 2 for Android Emulator Device Android 15

Update 3: Rewrite test case 1 & 2 for Samsung A7 2018 Android 9

Update 4: Merge 3 robot file into 1 single test suite

Update 5: Add dynamic locator for created contact and message

Update 6: Move Variable to JSON file